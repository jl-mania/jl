
# JAKALELANA Tour & Travel - Carousel Assets

Repository ini menyimpan aset gambar dan file HTML carousel untuk keperluan promosi website JAKALELANA Tour & Travel.

## Daftar Isi
- Gambar destinasi: Bali, Jogja, Solo, Malang
- File `index.html`: Carousel responsive dengan auto sliding dan preview antrian
- Menggunakan GitHub CDN (bisa via jsDelivr)

## Cara Penggunaan
- Embed `index.html` ke website Anda
- Atau gunakan GitHub Pages atau Google Sites
